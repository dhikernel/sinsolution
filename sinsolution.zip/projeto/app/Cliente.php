<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table = 'user_profiles';

    protected $fillable = ['nome', 'email', 'data_de_nascimento', 'usuario','criado_em', 'atualizado_em','status', 'foto', 'descricao'];    

    public $timestamps = false;
}