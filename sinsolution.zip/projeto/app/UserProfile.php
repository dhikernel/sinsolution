<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserProfile extends Authenticatable
{
    use Notifiable;
    public $table = "user_profiles";
    protected $fillable = [
         'nome', 'email', 'data_de_nascimento', 'usuario', 'password', 'criado_em', 'atualizado_em', 'relembrar_token', 'status', 'foto', 'descricao', 'cor'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
