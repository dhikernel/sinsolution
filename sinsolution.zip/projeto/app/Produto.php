<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{
    protected $fillable = ['titulo', 'condicao', 'tipo', 'categoria', 'descricao',  'preco', 'destaque', 'imagem_destaque', 'status'];

    public $timestamps = false;

}
