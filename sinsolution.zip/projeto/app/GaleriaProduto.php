<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GaleriaProduto extends Model
{
    protected $table = "galeria_produto";
    protected $fillable = ['produtoid', 'imagem'];
    public $timestamps = false;
}
