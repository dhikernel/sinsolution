<?php

namespace App\Http\Controllers\Auth;

use App\UserProfile;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ProfileResetPassController extends Controller
{
    //Show Forgot Password Form
    public function showForgotForm(){
        return view('forgotform');
    }

    //Reset Users Profile Password
    public function resetPass(Request $request){

        if (UserProfile::where('email', '=', $request->email)->count() > 0) {
            // user found
            $user = UserProfile::where('email', '=', $request->email)->firstOrFail();
            $autopass = str_random(8);
            $input['password'] = Hash::make($autopass);

            $user->update($input);
            $subject = "Redefinir solicitação de senha";
            $msg = "Sua nova senha é: ".$autopass;

            mail($request->email,$subject,$msg);
            Session::flash('success', 'Sua senha foi redefinida com sucesso. Por favor, verifique seu e-mail para obter uma nova senha.');
            return redirect(route('user.forgotpass'));

        }else{
            // user not found
            Session::flash('error', 'Nenhuma conta encontrada com este e-mail.');
            return redirect(route('user.forgotpass'));
        }
    }




}
