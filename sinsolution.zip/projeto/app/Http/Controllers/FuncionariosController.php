<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Validator;

class FuncionariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware(function ($request, $next) {
            if (Auth::user()->role != "administrator"){
                return redirect('admin/administradores')->with('error','Desculpe, você não é um administrador');
            }
            else{

                return $next($request);
            }
        });
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $funcionarios = User::all();
        return view('admin.funcionario.funcionarios',compact('funcionarios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function cadastrar()
    {
        return view('admin.funcionario.funcionariosadd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'photo.mimes' => 'Apenas JPG, arquivo PNG permitido para foto do funcionário',
            'email.unique' => 'Funcionário já existe com este e-mail',
            'email.required' => 'Por favor insira um e-mail pessoal',
            'password.min' => 'A senha deve ter 6 dígitos',
            'password.required' => 'Por favor, digite uma senha para o funcionário',
        ];

        $validator = Validator::make($request->all(),[
            'photo' => 'mimes:jpeg,bmp,png',
            'email' => 'required|email|max:255|unique:admin',
            'password' => 'required|min:6',
        ],$messages);

        if ($validator->passes()) {
            $funcionario = new User();
            $funcionario->fill($request->all());

            if ($file = $request->file('photo')){
                $photo_name = str_random(3).$request->file('photo')->getClientOriginalName();
                $file->move('assets/images/admin',$photo_name);
                $funcionario['photo'] = $photo_name;
            }
            $funcionario['password'] = Hash::make($request->password);

            $funcionario->save();
            return redirect('admin/administradores')->with('message','Novo colaborador adicionado com sucesso.');
        }
        return redirect('admin/administradores/create')->withErrors($validator)->withInput(Input::except('password'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $funcionario = User::findOrFail($id);
        return view('admin.funcionario.funcionariodetalhes',compact('funcionario'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $blog = User::findOrFail($id);
        $blog->delete();
        return redirect('admin/administradores')->with('message','Funcionário excluído com sucesso.');
    }
}
