<?php

namespace App\Http\Controllers;
use App\Settings;
use App\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class ClientesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = UserProfile::orderBy('id','desc')->get();
        return view('admin.cliente.clientelista',compact('clientes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
        public function cadastrar()
    {
        return view('admin.cliente.clienteadd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
        'email' => 'required|max:255|unique:user_profiles',
        ]);

        if ($validator->passes()) {
            $cliente = new UserProfile;
            $cliente->fill($request->all());

            if ($file = $request->file('foto')){
            $nome_foto = time().$request->file('foto')->getClientOriginalName();
            $file->move('assets/images/userprofile',$nome_foto);
            $cliente['foto'] = $nome_foto;
        }

            $cliente->save();
            Session::flash('message', 'Novo cliente adicionado com sucesso!');
            return redirect('admin/clientes');
        }
        Session::flash('message', 'E-mail já cadastrado em nossa base de dados, informe um e-mail diferente!');
            return redirect('admin/clientes/cadastrar');
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cliente = UserProfile::findOrFail($id);
        return view('admin.cliente.clientedetalhes',compact('cliente'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function editar($id)
    {
        $cliente = UserProfile::findOrFail($id);
        return view('admin.cliente.clienteeditar',compact('cliente'));
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request, $id)
    {
        $cliente = UserProfile::findOrFail($id);
        $data = $request->all();

        if ($file = $request->file('foto')){
            $nome_foto = time().$request->file('foto')->getClientOriginalName();
            $file->move('assets/images/userprofile',$nome_foto);
            $data['foto'] = $nome_foto;
        }
        $cliente->update($data);
        return redirect('admin/clientes')->with('message','Cliente atualizado com sucesso!');;
    }

    public function status($id,$status)
    {
        $cliente = UserProfile::findOrFail($id);
        $data['status']=$status;
        $cliente->update($data);
        return redirect('admin/clientes')->with('message','Status da conta do cliente alterado com sucesso!');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */    
    public function deletar($id)
    {   

        $cliente = UserProfile::findOrFail($id);
        
        if (!file_exists(public_path().'/assets/images/userprofile/'.$cliente->foto)) {
            
                    $cliente->delete();
            
        }else{
            
        unlink('assets/images/userprofile/'.$cliente->foto);

        $cliente->delete();
        
        }

        return redirect('admin/clientes')->with('message','Cliente excluido com sucesso!');
    }
    /*
    public function deletar($id)
    {

        $cliente = UserProfile::findOrFail($id);
        unlink('assets/images/userprofile/'.$cliente->foto);
        $cliente->delete();
        return redirect('admin/clientes')->with('message','Cliente excluido com sucesso!');
    }
    */  
}
