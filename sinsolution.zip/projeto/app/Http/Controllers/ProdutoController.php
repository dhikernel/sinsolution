<?php

namespace App\Http\Controllers;

use App\Produto;
use App\GaleriaProduto;
use App\SectionTitles;
use App\Settings;
use App\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class ProdutoController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
        $produtos = Produto::orderBy('id','desc')->get();
        return view('admin.produto.produtolista',compact('produtos'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function cadastrar()
    {        
        return view('admin.produto.produtoadd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)    {
        $produto = new Produto;
        //$produto->fill($request->all());
        
        $produto->titulo = $request->titulo;
        $produto->condicao = $request->condicao;
        $produto->tipo = $request->tipo;
        $produto->categoria = $request->categoria;
        $produto->descricao = $request->descricao;
        $produto->preco = substr((float)(preg_replace('/[^0-9]+/','',$request->preco)), 0, -2);
        $produto->destaque = $request->destaque;

        if ($file = $request->file('foto')){
            $nome_foto = time().$request->file('foto')->getClientOriginalName();
            $file->move('assets/images/produto',$nome_foto);
            $produto['imagem_destaque'] = $nome_foto;
        }        
        $produto->save();
        $ultimoid = $produto->id;

        if ($files = $request->file('galeria')){
            foreach ($files as $file){
                $galeria = new GaleriaProduto();
                $nome_imagem = str_random(2).time().$file->getClientOriginalName();
                $file->move('assets/images/galeria',$nome_imagem);
                $galeria['imagem'] = $nome_imagem;
                $galeria['produtoid'] = $ultimoid;
                $galeria->save();
            }
        }

        return redirect('admin/produtos')->with('message','Novo produto cadastrado com sucesso!.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $produto = Produto::findOrFail($id);        
        return view('admin.produto.produtodetalhes',compact('produto'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editar($id)
    {        
        $produto = Produto::findOrFail($id);
        return view('admin.produto.produtoeditar',compact('produto'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $produto = Produto::findOrFail($id);        
        $produto->titulo = $request->titulo;
        $produto->condicao = $request->condicao;
        $produto->tipo = $request->tipo;
        $produto->categoria = $request->categoria;
        $produto->descricao = $request->descricao;        
        $produto->preco = substr((float)(preg_replace('/[^0-9]+/','',$request->preco)), 0, -2);
        $produto->destaque = $request->destaque;

        $produto->destaque = $request->destaque;    

        if ($file = $request->file('foto')){
            $nome_foto = time().$request->file('foto')->getClientOriginalName();
            $file->move('assets/images/produto',$nome_foto);
            $data['imagem_destaque'] = $nome_foto;
        }

        if ($request->galdel == 1){
            $gal = GaleriaProduto::where('produtoid',$id);
            $gal->delete();            
        }        

        if ($request->destaque == 1){
            $data['destaque'] = 1;
        }else{
            $data['destaque'] = 0;
        }

        $produto->update($data);

        if ($files = $request->file('galeria')){
            foreach ($files as $file){
                $galeria = new GaleriaProduto;
                $nome_imagem = str_random(2).time().$file->getClientOriginalName();
                $file->move('assets/images/galeria',$nome_imagem);
                $galeria['imagem'] = $nome_imagem;
                $galeria['produtoid'] = $id;
                $galeria->save();
            }
        }

        return redirect('admin/produtos')->with('message','Produto atualizado com sucesso!');
    }

    public function status($id,$status)
    {
        $produto = Produto::findOrFail($id);
        $data['status']=$status;
        $produto->update($data);
        return redirect('admin/produtos')->with('message','Status do produto foi alterado com sucesso!');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */    

    public function deletar($id)
    {
        
        GaleriaProduto::where('produtoid',$id)->delete();

        $produto = Produto::findOrFail($id);

        unlink('assets/images/produto/'.$produto->imagem_destaque);

        $produto->delete();

        return redirect('admin/produtos')->with('message','Produto excluído com sucesso!');
    }

}
