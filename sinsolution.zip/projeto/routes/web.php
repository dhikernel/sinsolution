<?php

use App\UsersModel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Aqui é onde você pode registrar rotas da web para seu aplicativo. Estes
| rotas são carregadas pelo RouteServiceProvider dentro de um grupo que
| contém o grupo de middleware "web". Agora crie algo ótimo!
|
*/
Route::get('/', 'FrontEndController@index');

Route::get('/admin', function () {
    return view('admin.index');
})->name('admin.login');

Route::get('/login', function () {
    return view('admin.login');
});

Auth::routes();
/*Configurações*/
Route::get('admin/settings/logo', 'SettingsController@logoform');
Route::get('admin/settings/favicon', 'SettingsController@faviconform');
Route::get('admin/settings/rodape', 'SettingsController@footerform');
Route::post('admin/settings/favicon', 'SettingsController@favicon');
Route::post('admin/settings/footer', 'SettingsController@footer');
Route::post('admin/settings/logo', 'SettingsController@logo');
Route::resource('/admin/settings', 'SettingsController');
Route::get('/admin/administradores/cadastrar', 'FuncionariosController@cadastrar');
Route::resource('/admin/administradores', 'FuncionariosController');
Route::post('/admin/adminpassword/change/{id}', 'AdminProfileController@changepass');
Route::get('/admin/mudar-senha', 'AdminProfileController@password');
Route::resource('/admin/perfil', 'AdminProfileController');
/*Configurações*/

/*Clientes*/
Route::get('/admin/clientes/cadastrar', 'ClientesController@cadastrar');
Route::get('/admin/clientes/status/{id}/{status}', 'ClientesController@status');
Route::get('/admin/clientes/{id}/editar', 'ClientesController@editar');
Route::get('/admin/clientes/{id}/deletar', 'ClientesController@deletar');
Route::resource('/admin/clientes', 'ClientesController');
/*Clientes*/

/*Produtos*/
Route::get('/admin/produtos/cadastrar', 'ProdutoController@cadastrar');
Route::get('/admin/produtos/{id}/deletar', 'ProdutoController@deletar');
Route::get('/admin/produtos/{id}/editar', 'ProdutoController@editar');
Route::get('/admin/produtos/status/{id}/{status}', 'ProdutoController@status');
Route::resource('/admin/produtos', 'ProdutoController');
/*Produtos*/

Route::post('/usuario/senha/change/{id}', 'UserProfileController@changepass');
Route::get('/usuario/senha', 'UserProfileController@password');
Route::get('/usuario/perfil', 'UserProfileController@profile');
Route::post('/usuario/update/{id}', 'UserProfileController@update');
Route::get('/usuario/login', 'Auth\ProfileLoginController@showLoginFrom')->name('user.login');
Route::post('/usuario/login', 'Auth\ProfileLoginController@login')->name('user.login.submit');

