<script type="text/javascript">
location.href = '{{url('/')}}/admin';
</script>