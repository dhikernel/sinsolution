@extends('admin.includes.masterpage-admin')
<script src="{{ URL::asset('assets/mask/jquery.min.js')}}"></script>
<script src="{{ URL::asset('assets/mask/jquery.maskMoney.js')}}"></script>
@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    {{-- Inicio --}}
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Cadastrar produto</h2>
                                        <a href="{!! url('admin/produtos') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                                    </div>
                                    <hr/>
                                    <form method="POST" action="{!! action('ProdutoController@store') !!}" class="form-horizontal"  enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="titulo">Produto*</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="titulo" id="titulo" placeholder="Informe o título do produto" required>
                                            </div>
                                        </div>                                       
                                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="condicao">Selecionar condição *</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="condicao" id="condicao">
                                                    <option value="">Selecione a condição</option>
                                                    <option value="novo">Novo</option>
                                                    <option value="usado">Usado</option>
                                                    <option value="Reformado">Reformado</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="tipo">Selecione o tipo de produto *</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="tipo" id="tipo">
                                                    <option value="">Selecione o tipo de produto</option>
                                                    <option value="tipo 1">Tipo 1</option>
                                                    <option value="tipo 2">Tipo 2</option>
                                                    <option value="tipo 3">Tipo 3</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="categoria">Selecione a categoria*</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" name="categoria" id="categoria">
                                                    <option value="">Selecione a categoria do produto</option>
                                                    <option value="Categoria 1">Categoria 1</option>
                                                    <option value="Categoria 2">Categoria 2</option>
                                                    <option value="Categoria 3">Categoria 3</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="foto">Foto em destaque*</label>
                                            <div class="col-sm-6">
                                                <img src="{{ URL::asset('assets/images/produto/padrao.png')}}" style="max-width: 200px;" alt="Nenhuma foto adicionada" id="docphoto">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="foto">Selecionar foto *</label>
                                            <div class="col-sm-6">
                                                <input type="file" accept="image/*" name="foto" class="hidden" onchange="readURL(this)" id="uploadFile"/>
                                                <div id="uploadTrigger" class="btn btn-info"><span class="fa fa-cloud-upload"></span> Click para adicionar a foto!</div><br><br>
                                                <span style="color: green; font-weight: bold;">Proporção preferível 1x1</span>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="galeria_produto">Imagens da galeria de produtos <span>(Optional) </span></label>
                                            <div class="col-sm-6">
                                                <input type="file" accept="image/*" name="galeria[]" multiple/>
                                                <p>Imagem múltipla permitida</p>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="descricao">Descrição do produto*</label>
                                            <div class="col-sm-6">
                                                <textarea class="form-control" name="descricao" id="descricao" rows="5" style="resize: vertical;"></textarea>
                                            </div>
                                        </div>                              

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="auction_buy_price">Valor do produto*</label>
                                            <div class="col-sm-6">
                                                <input id="preco" type="text" class="form-control" name="preco" placeholder="R$: 0,00 Informe o valor do produto" required data-thousands="." data-decimal="," data-prefix="R$: ">
                                                <script type="text/javascript">$("#preco").maskMoney();</script>                                             
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4"></label>
                                            <div class="col-sm-6" data-toggle="buttons">
                                                <div class="btn btn-success">
                                                    <input type="checkbox" name="destaque" value="1" autocomplete="off">
                                                    <span class="go_checkbox"><i class="glyphicon glyphicon-ok"></i></span>
                                                    Adicionar produto em Destaque
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Cadastrar produto</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- Fim --}}

                </div>
            </div>
        </div>


@stop
@section('footer')
    <script type="text/javascript">


        $("#uploadTrigger").click(function(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                $("#uploadTrigger").html($("#uploadFile").val());
            });
        });
        function readURL(input) {

            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#docphoto').attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        bkLib.onDomLoaded(function() {
            new nicEditor({fullPanel : true}).panelInstance('descricao');
        });
    </script>
@stop