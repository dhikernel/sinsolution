@extends('admin.includes.masterpage-admin')
<?php
/* Inicia conexão com o banco de dados */
$servername = getenv('DB_HOST');
$username = getenv('DB_USERNAME');
$password = getenv('DB_PASSWORD');
$dbname = getenv('DB_DATABASE');
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Falha na conexão: " . mysqli_connect_error());
if (mysqli_connect_error()) {
printf("Falha na conexão: %s\n", mysqli_connect_error());
exit();
}
?>
<script src="{{ URL::asset('assets/mask/jquery.min.js')}}"></script>
<script src="{{ URL::asset('assets/mask/jquery.maskMoney.js')}}"></script>
@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<!-- Starting of Dashboard view auction details area -->
<div class="section-padding add-product-1">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="add-product-box">
            <div class="add-product-header campaigns">
                <h2>Detalhes do Leilão</h2>
                <a href="{!! url('admin/leiloes') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
            </div>
            <hr/>

            <div class="campaign-tab">
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#bid">Dar Lance</a></li>
                    <li><a data-toggle="tab" href="#campaignDetails">Detalhes do Leilão</a></li>
                    <li><a data-toggle="tab" href="#donations">Informações Sobre Lances</a></li>
                </ul>

                <div class="tab-content">
                    <div id="bid" class="tab-pane fade in active">
                        <div style="text-align: center;" class="add-product-header">                                      
                                        <h2 style="color: #5cb85c; font-weight: bold;">&nbsp;  Lance Incial <i class="fa fa-fw fa-arrow-circle-right"></i>
                                        R$: {{number_format($auction->start_amount, 2, ',', '.')}}</h2>

                                    </div>
                        <div style="text-align: center;" class="add-product-header">                                      
                                        <h2 style="color: #337ab7; font-weight: bold;">&nbsp;  Maior Lance <i class="fa fa-fw fa-arrow-circle-right"></i>
                                        R$: {{\App\Bid::maxBid($auction->id)}}</h2>

                                    </div>
                                    <hr/>
                                    <div id="response" class="col-md-12">
                                        @if(Session::has('message'))
                                            <div class="alert alert-success alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                {{ Session::get('message') }}
                                            </div>
                                        @endif
                                    </div>

                                    <form method="POST" action="{!! action('PlateletController@store') !!}" class="form-horizontal" enctype="multipart/form-data">

                                        {{csrf_field()}}

                                        <div class="form-group">
                                        <label class="control-label col-sm-3" for="auctionid">Nome do Leilão *</label>
                                        <div class="col-sm-6">

                               <input type="hidden" name="auctid" id="auctid" value="{{$auction->id}}">
                               <input type="hidden" name="auctionid" id="auctionid" value="{{$auction->id}}">

                               <div title="Você está dando lance para o leilão: {{$auction->title}}" class="form-control" readonly disabled>{{$auction->title}}</div>
                                            </div>
                                        </div>      

                                        <div class="form-group">
                                        <label class="control-label col-sm-3" for="bidder">Selecionar Usuário *</label>
                                        <div class="col-sm-6">
                                        <select class="form-control" name="bidder" id="bidder" required>
                                        <option value="">Selecione o Usuário Cadastrado</option>
                                        <?php
                                        
                                        $sql = "SELECT * FROM user_profiles";
                                        
                                        $query = mysqli_query($conn, $sql);                                

                                        while($rows = mysqli_fetch_assoc($query)){

                                        if ($query->num_rows > 0) {    

                                        $id = $rows['id'];    

                                        $name = $rows['name'];
                                        
                                        ?>                                        
                                        <option value="<?php echo $id; ?>"><?php echo utf8_encode($name); ?></option>

                                        <?php }} ?>

                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="bid_amount">
                                            Valor do Lance*</label>
                                            <div class="col-sm-6">
                                    <input type="text" id="bid-amount" title="Maior lance até o momento: R$: {{\App\Bid::maxBid($auction->id)}}" name="bid_amount" class="form-control" placeholder="R$: {{\App\Bid::maxBid($auction->id)}}" required  onclick="myFunctionclear()" data-thousands="." data-decimal="," data-prefix="R$: " />
                                    <script type="text/javascript">$("#bid-amount").maskMoney();</script><br>
                                        </div>

                                        </div>

                                        <div align="center">
                                            
                                        <button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction1()"><i class="fa fa-money"></i> R$: 50,00</button>&nbsp;<button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction2()"><i class="fa fa-money"></i> R$: 100,00</button>&nbsp;<button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction3()"><i class="fa fa-money"></i> R$: 150,00</button>
                                        <br><br>
                                        <button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction4()"><i class="fa fa-money"></i> R$: 200,00</button>&nbsp;<button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction5()"><i class="fa fa-money"></i> R$: 250,00</button>&nbsp;<button style="width:100px;" class="btn btn-primary dropdown-toggle btn-xs" type="button" onclick="myFunction6()"><i class="fa fa-money"></i> R$: 300,00</button>
                                        <br><br>

                                        </div>

                                        <hr/>                                        
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-success"><i class="fa fa-gavel"></i> Dar o Lance!</button>
                                        </div>
                                    </form>                        
                    </div>
                    <div id="campaignDetails" class="tab-pane fade">
                        <h3>{{$auction->title}}</h3>

                        <div class="table-responsive">
                            <table class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                <tbody>
                                <tr>
                                    <td width="30%"><strong>Leilão ID#</strong></td>
                                    <td>{{$auction->id}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Status do Leilão:</strong></td>
                                    <td><?php if (ucfirst($auction->status) == 'Open') { echo "Aberto";} elseif (ucfirst($auction->status) == 'Closed') { echo "Fechado"; } elseif (ucfirst($auction->status) == 'Pending') {echo "Pendente"; } elseif (ucfirst($auction->status) == 'Reject') { echo "Rejeitado";} else{ echo ""; } ?></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Em Destaque:</strong></td>
                                    <td>
                                        @if($auction->featured == 1)
                                            <label class="label label-primary">Destaque</label>
                                        @else
                                            <label class="label label-default">Básico</label>
                                        @endif
                                    </td>
                                </tr>
                                
                                

                                @if($auction->winner != '')
                                    <tr class="success">
                                        <td width="30%"><strong style="color:#5bab34;"> Vencedor: </strong></td>
                                        <td>{{\App\Bid::findOrFail($auction->winner)->bidder->name}}</td>
                                    </tr>
                                    <tr class="success">
                                        <td width="30%"><strong> Total do Vencedor: </strong></td>

                                        <?php $bid_amount = \App\Bid::findOrFail($auction->winner)->bid_amount; ?>
                                        <td>R$:<?php echo number_format($bid_amount, 2, ',', '.'); ?></td>
                                    </tr>
                                @elseif($auction->winner == '')
                                <tr class="success">
                                        <td width="30%"><strong style="color:#d43f3a;"> Leilão sem vencedor!</strong></td>
                                        <td width="30%"><strong style="color:#d43f3a;"> &nbsp; </strong></td>
                                    </tr>
                                @endif

                                <tr>
                                    <td width="30%"><strong>Criado em:</strong></td>
                                    <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%d/%m/%Y &agrave;s %H:%M:%S", strtotime($auction->created_at)))); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Data Final:</strong></td>
                                    <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%d/%m/%Y &agrave;s %H:%M:%S", strtotime($auction->end_date)))); ?></td>
                                </tr>
                                <tr>
                                    {{--
                                    <td width="30%"><strong>Criado Por:</strong></td>
                                    <td>{{$auction->createdby->name}}</td>
                                    --}}
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Título do Leilão:</strong></td>
                                    <td>{{$auction->title}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Categoria de Leilão:</strong></td>
                                    <td>{{$auction->category}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Condição do Item:</strong></td>
                                    <td><?php if (ucfirst($auction->condition) == 'New') { echo "Novo";} elseif (ucfirst($auction->condition) == 'Used') { echo "Usado"; } elseif (ucfirst($auction->condition) == 'Recondition') {echo "Reformado"; } else { echo "";} ?></td>
                                </tr>

                                <tr>
                                    <td width="30%"><strong>Preço Compre Agora:</strong></td>
                                    <td>R$: {{number_format((float)($auction->price), 2,",",".")}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Valor Inicial do Leilão:</strong></td>
                                    <td>R$: {{number_format((float)($auction->start_amount), 2,",",".")}}</td>

                                </tr>
                                <tr>
                                    <td width="30%"><strong>Imagem em Destaque:</strong></td>
                                    <td><img style="max-width: 300px;" src="{{url('assets/images/auction')}}/{{$auction->feature_image}}" ></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Descrição do Leilão:</strong></td>
                                    <td>{!! $auction->description !!}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="donations" class="tab-pane fade">
                        <h3>Lances Totais: {{\App\Bid::countBid($auction->id)}}</h3>
                        <h3>Maior Lance: R$:{{\App\Bid::maxBid($auction->id)}}</h3>

                        <div class="table-responsive">
                            <table class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                <thead>
                                <tr>
                                    <th>Licitante</th>
                                    <th>Valor da oferta</th>
                                    <th>Data</th>
                                    <th>Ação</th>
                                </tr>
                                </thead>

                                <tbody>
                                @foreach($bids as $bid)
                                    @if($auction->winner == $bid->id)
                                        <tr class="success">
                                    @else
                                        <tr>
                                            @endif
                                            <td>{{$bid->bidder->name}}</td>
                                            <td>R$:{{number_format($bid->bid_amount, 2, ',', '.')}}
                                            </td>
                                            <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%d de %b de %Y &agrave;s %H:%M:%S", strtotime($bid->updated_at)))); ?></td>
                                            
                                            </td>
                                            <td>
                                                @if($bid->auctionid->winner == "")
                                                    <a href="{{url('admin/leiloes/'.$bid->id.'/winner/'.$auction->id)}}" class="btn btn-success btn-xs">Tornar vencedor</a>
                                                @else
                                                    @if($auction->winner == $bid->id)
                                                        <strong style="color:#4cae4c;">Vencedor</strong> (<a href="{{url('admin/leiloes/'.$auction->id.'/cwinner')}}" style="color: red;">Remover</a>)
                                                    @else
                                                        Leilão concluído
                                                    @endif
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>                    
                </div>
            </div>
            <hr/>
        </div>
    </div>
</div>
</div>
<!-- Ending of Dashboard view auction details area -->

</div>
</div>
</div>
</div>

@stop
@section('footer')
<?php $highest = preg_replace('/[^0-9]+/','',(\App\Bid::maxBid($auction->id))); ?>
<?php $highestok = number_format((float)$highest, 2, ',', ''); ?>
<?php $soma1 = substr((float)$highestok + '5000', 0, -2) ?>
<?php $soma2 = substr((float)$highestok + '10000', 0, -2) ?>
<?php $soma3 = substr((float)$highestok + '15000', 0, -2) ?>
<?php $soma4 = substr((float)$highestok + '20000', 0, -2) ?>
<?php $soma5 = substr((float)$highestok + '25000', 0, -2) ?>
<?php $soma6 = substr((float)$highestok + '30000', 0, -2) ?>


<script type="text/javascript">

function myFunctionclear() {
document.getElementById("bid-amount").readOnly = false;
}

function myFunction1() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma1,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
function myFunction2() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma2,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
function myFunction3() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma3,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
function myFunction4() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma4,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
function myFunction5() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma5,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
function myFunction6() {
document.getElementById("bid-amount").value="R$:<?php echo number_format((float)$soma6,2,",","."); ?>";
document.getElementById("bid-amount").readOnly = true;
}
</script>
@stop