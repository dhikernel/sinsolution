@extends('admin.includes.masterpage-admin')

@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of All Auctions area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header campaigns">
                                        <h2>Lista de Produtos</h2>
                                        <a href="{!! url('admin/produtos/cadastrar') !!}" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Criar novo produto
                                        </a>
                                    </div>
                                    <hr/>
                                    <div class="table-responsive">
                                        <div class="col-md-12">
                                            @if(Session::has('message'))
                                                <div class="alert alert-success alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                    {{ Session::get('message') }}
                                                </div>
                                            @endif
                                        </div>
                                        <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                            <thead>
                                            <tr>
                                                <th style="font-weight: bold;">ID#</th>
                                                <th width="10%" style="font-weight: bold;">Imagem</th>
                                                <th style="font-weight: bold;">Título</th>
                                                <th style="font-weight: bold;">Condição</th>
                                                <th style="font-weight: bold;">Tipo</th>
                                                <th style="font-weight: bold;">Categoria</th>
                                                <th style="font-weight: bold;">Preço</th>
                                                <th style="font-weight: bold;">Destaque</th>
                                                <th style="font-weight: bold;">Status</th>
                                                <th style="font-weight: bold;">Ações</th>
                                            </tr>
                                            </thead>

                                            <tbody>
                                                
                                            @foreach($produtos as $produto)
                                                <tr>                                                   
                                                    <td style="font-weight: bold;">{{$produto->id}}</td>
                                                    <td width="10%" style="font-weight: bold;">
                                                    @if($produto->imagem_destaque == '')
                                                    <label class="label label-danger"><i class="fa fa-fw fa-times"></i> Sem imagem</label>
                                                    @else
                                                    <img style="border: 3px solid #ddd;" src="{{url('assets/images/produto')}}/{{$produto->imagem_destaque}}" alt="Nenhuma imagem adicionada">
                                                    @endif
                                                    </td>
                                                    <td style="font-weight: bold;">{{$produto->titulo}}</td>
                                                    <td style="font-weight: bold;">{{$produto->condicao}}</td>
                                                    <td style="font-weight: bold;">{{$produto->tipo}}</td>
                                                    <td style="font-weight: bold;">{{$produto->categoria}}</td>
                                                    <td style="font-weight: bold;">R$:{{number_format((float)($produto->preco), 2,",",".")}}</td>
                                                    
                                                    <td style="font-weight: bold;">
                                                        @if($produto->destaque == 1)
                                                            <label class="label label-primary">Destaque</label>
                                                        @else
                                                            <label class="label label-default">Básico</label>
                                                        @endif
                                                    </td>                                                    

                                                    <td>
                                                     @if ($produto->status == 1)
                                                        <span style="color: #5cb85c; font-weight: bold;">Ativo</span>
                                                        @else
                                                        <span style="color: #d43f3a; font-weight: bold;">Desativado</span>
                                                        @endif
                                                    </td>        
                                                    <td><span style="font-weight: bold;">
                                                    <a href="produtos/{{$produto->id}}/editar" class="btn btn-primary product-btn"><i class="fa fa-edit"></i> Editar </a>
                                                    @if($produto->status != 0)
                                                    <a href="produtos/status/{{$produto->id}}/0" class="btn btn-warning product-btn"><i class="fa fa-toggle-off"></i> Desativar</a>
                                                    @else
                                                    <a href="produtos/status/{{$produto->id}}/1" class="btn btn-success product-btn"><i class="fa fa-toggle-on"></i> Ativar</a>
                                                    @endif
                                                    <a href="javascript:;" data-href="{{url('/')}}/admin/produtos/{{$produto->id}}/deletar" data-toggle="modal" data-target="#confirmar-deletar"class="btn btn-danger product-btn"><i class="fa fa-trash"></i></a>

                                                </td>
                                                </tr>
                                            @endforeach

                                            </tbody>
                                        </table>
                                    </div>
                                    <hr/>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- Fim --}}


                </div>
            </div>
        </div>
    </div>



    <div class="modal table-modal fade" id="confirmar-deletar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content panel-danger">
                <div class="modal-header panel-heading">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title" id="myModalLabel"><i class="fa fa-exclamation-circle fa-fw"></i> Confirme a Exclusão</h3>
                </div>
                <div class="modal-body">
                    <p>Você está prestes a excluir este leilão, todos os lances serão excluídas para este leilão.</p>
                    <h4>Você deseja prosseguir?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-danger btn-ok">Excluir</a>
                </div>
            </div>
        </div>
    </div>

@stop

@section('footer')
    <script>
        $('#confirmar-deletar').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    </script>
@stop