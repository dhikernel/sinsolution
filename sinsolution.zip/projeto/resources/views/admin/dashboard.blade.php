@extends('admin.includes.masterpage-admin')
<?php                                         
/* Inicia conexão com o banco de dados */
$servername = getenv('DB_HOST');
$username = getenv('DB_USERNAME');
$password = getenv('DB_PASSWORD');
$dbname = getenv('DB_DATABASE');
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Falha na conexão: " . mysqli_connect_error());
if (mysqli_connect_error()) {
printf("Falha na conexão: %s\n", mysqli_connect_error());
exit();
}
?>
@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <!-- Starting of Dashboard header items area -->
        <div class="panel panel-default admin">                        
            <div style="font-size: 20px; text-transform: uppercase;" class="panel-heading admin-title">Aniversariante do mês <span style="color:#286090;">In</span><span style="color:#76b14c;">Decks</span></div>
            <div class="panel-body dashboard-body">
                <div class="dashboard-header-area">
                    <div class="row">                        
                </div>
            </div>
        </div>
    </div>

        <!-- Fim da área de itens de cabeçalho do painel -->

            </div>
        </div>
    </div>
</div>
@stop

@section('footer')

@stop