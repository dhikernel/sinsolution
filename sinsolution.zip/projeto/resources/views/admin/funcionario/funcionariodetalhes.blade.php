@extends('admin.includes.masterpage-admin')

@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard FAQ Page -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Informações do Funcionário</h2>
                                        <a href="{!! url('admin/administradores') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                                    </div>
                                    <div id="imprimir">
                                    <div class="table-responsive order-details-table">
                                        <table class="table">
                                            <tr>
                                                <th>ID do Funcionário#</th>
                                                <td>{{$funcionario->id}}</td>
                                            </tr>
                                            <tr>
                                                <th>Foto</th>                                           
<td><img id="adminimg" style="width: 250px;" src="{{url('/')}}/assets/images/admin/{{$funcionario->photo}}" alt="Nem uma foto encontrada"></td>
                                                
                                            </tr>
                                            <tr>
                                                <th>Nome do Funcionário:</th>
                                                <td>{{$funcionario->name}}</td>
                                            </tr>
                                            <tr>
                                                <th>Função:</th>
                                                <td>{{ucfirst($funcionario->role)}}</td>
                                            </tr>
                                            <tr>
                                                <th>E-mail:</th>
                                                <td>{{$funcionario->email}}</td>
                                            </tr>
                                            <tr>
                                                <th>Celular | Telefone:</th>
                                                <td>{{$funcionario->phone}}</td>
                                            </tr>
                                            <tr>
                                                <th>Ingressou:</th>
                                                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%A, %d de %B de %Y", strtotime($funcionario->criado_em)))); ?></td>

                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                    <div class="row no-print">
                          <div class="col-xs-12">
                          <button style="float: right; margin-top:-2px; margin-right: 30px;" class="btn btn-primary" onclick="printDiv('imprimir');"><i class="fa fa-print"></i> Imprimir</button>                          
                        </div>
                        </div>
                                    <hr/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard FAQ Page -->

                </div>
            </div>
        </div>
    </div>

@stop

@section('footer')
<script type="text/javascript">
function printDiv(imprimir){    
     var printContents = document.getElementById('imprimir').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     window.close();         
}
</script>

@stop