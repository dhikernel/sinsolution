@extends('admin.includes.masterpage-admin')

@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2 class="title">Adicionar Funcionário</h2>
                                        <a href="{!! url('admin/administradores') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                                    </div>
                                    <hr/>
                                    <div id="response">
                                        @if($errors->has('photo'))
                                            <div class="alert alert-danger alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                {{ $errors->first('photo') }}
                                            </div>
                                        @endif
                                        @if($errors->has('email'))
                                            <div class="alert alert-danger alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                {{ $errors->first('email') }}
                                            </div>
                                        @endif
                                        @if($errors->has('password'))
                                            <div class="alert alert-danger alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                {{ $errors->first('password') }}
                                            </div>
                                        @endif
                                    </div>
                                    <form method="POST" action="{!! action('FuncionariosController@store') !!}" class="form-horizontal" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="slider_text _position">Função*</label>
                                            <div class="col-sm-6">
                                                <select id="slider_text _position" name="role" class="form-control" required>
                                                    <option value="">Selecione a Função do Colaborador</option>
                                                    <option value="administrator">Administrador</option>
                                                    <option value="colaborador">Colaborador</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="name">Nome do Colaborador*</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="name" id="name" placeholder="Informe o nome do Colaborador" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="username">Usuário*</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="username" id="username" placeholder="Ex: josesouza" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="service_icon">Foto*</label>
                                            <div class="col-sm-6">
                                                <input type="file" name="photo" id="service_icon" accept="image/*">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                        <label class="control-label col-sm-3" for="service_text">E-mail* <span>(Será usado para login)</span></label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="email" placeholder="O e-mail será usado para fazer o login no sistema" id="service_title" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="service_title3">Celular ou Telefone* </label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="phone" id="phone" autocomplete="off" placeholder="Digite o número do seu celular ou telefone fixo" id="service_title3">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="service_title2">Senha* <span style="color: red; font-weight: bold;">(Será usada para login)</span></label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Insira a Senha da Equipe" id="service_title2" required>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button style="height: 41px;" name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Adicionar Colaborador</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->

                </div>
            </div>
        </div>
    </div>


@stop

@section('footer')

    <script type="text/javascript">
        bkLib.onDomLoaded(function() {
            new nicEditor({fullPanel : true}).panelInstance('content1');
        });
    </script>
    <script src="{{ URL::asset('assets/js/jquery.mask.min.js')}}"></script>
    <script type="text/javascript">
    var PhoneMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 9 ? '(00)0000-0009' : '(00)0000-00009';
        },
    PhonepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PhoneMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#phone').mask(PhoneMaskBehavior, PhonepOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
</script>
@stop