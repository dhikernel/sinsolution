@extends('admin.includes.masterpage-admin')

@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        {{-- Inicio --}}
        <div class="section-padding add-product-1">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="add-product-box">
                        <div class="add-product-header">
                            <h2 class="title">Detalhes do Cliente</h2>
                            <a href="{!! url('admin/clientes') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                        </div>
                        <hr/>
                        <div id="imprimir">
                        <div class="table-responsive order-details-table">
                            <table class="table">                                
                                <tr>
                                    <td width="30%"><strong>Status da Conta: </strong></td>
                                    @if($cliente->status != 0)
                                        <td style="color: #008000;"> <strong>Ativo</strong></td>
                                    @else
                                        <td style="color: #ff0000;"><strong>Desativado</strong></td>
                                    @endif
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Nome Completo:</strong></td>
                                    <td>{{$cliente->nome}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Nome de Usuário:</strong></td>
                                    <td>{{$cliente->usuario}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>E-mail do Usuário:</strong></td>
                                    <td>{{$cliente->email}}</td>
                                </tr>                                
                                <tr>
                                    <td width="30%"><strong>Data de Nascimento:</strong></td>
                                    <td>{{$cliente->data_de_nascimento}}</td>
                                </tr>                                
                                <tr>
                                    <td width="30%"><strong>Ingressou:</strong></td>
                                    <td>
                                    <span><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%d de %B de %Y &agrave;s %H:%M:%S", strtotime($cliente->criado_em)))); ?>
                                    </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Foto de Perfl:</strong></td>
                                    <td>
                                    @if($cliente->foto == '')    
                                    <img style="max-width: 200px; max-height: 200px;" src="{{ URL::asset('assets/images/padrao.png')}}" width="auto" height="auto" />
                                    @else
                                        <img style="max-width: 200px; max-height: 200px;" src="{{ URL::asset('assets/images/userprofile')}}/{{$cliente->foto}}" width="auto" height="auto" />@endif
                                    </td>
                                </tr>                                
                            </table>
                        </div>
                    </div>
              <div class="row no-print">
              <div class="col-xs-12">
              <button style="float: right; margin-top:-2px; margin-right: 30px;" class="btn btn-primary" onclick="printDiv('imprimir');"><i class="fa fa-print"></i> Imprimir</button>                          
                </div>
                </div>
                <hr />
                        
                    </div>
                </div>
            </div>
            
        </div>
        {{-- Fim --}}
        
    </div>
</div>
</div>
</div>

@stop

@section('footer')
<script type="text/javascript">
function printDiv(imprimir){    
var printContents = document.getElementById('imprimir').innerHTML;
var originalContents = document.body.innerHTML;
document.body.innerHTML = printContents;
window.print();
document.body.innerHTML = originalContents;
window.close();         
}
</script>

@stop