@extends('admin.includes.masterpage-admin')

@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<!-- Starting of Dashboard Users area -->
<div class="section-padding add-product-1">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="add-product-box customers">                                 
        <div class="add-product-header">
            <h2 class="title">Clientes <i class="fa fa-users"></i></h2>
            <a href="{!! url('admin/clientes/cadastrar') !!}" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Cadastrar Cliente</a>
        </div>
        <hr/>
        <div class="table-responsive">
            <div class="col-md-12">
                @if(Session::has('message'))
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        {{ Session::get('message') }}
                    </div>
                @endif
            </div>
            <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Imagem</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Data de Nascimento</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
                </thead>
                <tbody>
                @foreach($clientes as $cliente)
                    <tr>
                        <td style="width: 10%;">
                        @if($cliente->foto == '')
                        <label class="label label-danger"><i class="fa fa-fw fa-times"></i> Sem imagem</label>
                        @else
                    <img src="{{url('assets/images/userprofile')}}/{{$cliente->foto}}" alt="Nenhuma imagem adicionada">
                        @endif
                        </td>
                        <td>{{$cliente->nome}}</td>
                        <td>{{$cliente->email}}</td>
                        <td>{{$cliente->data_de_nascimento}}</td>
                        <td>
                            @if($cliente->status != 0)
                                <b style="color: #5cb85c;">Ativo</b>
                            @else
                                <b style="color: #D75357;">Desativado</b>
                            @endif
                        </td>

                        <td><span style="font-weight: bold;">
                        <a href="clientes/{{$cliente->id}}" class="btn btn-info product-btn"><i class="fa fa-eye"></i> Detalhes </a>
                        <a href="clientes/{{$cliente->id}}/editar" class="btn btn-primary product-btn"><i class="fa fa-edit"></i> Editar </a>
                        @if($cliente->status != 0)
                        <a href="clientes/status/{{$cliente->id}}/0" class="btn btn-warning product-btn"><i class="fa fa-toggle-off"></i> Desativar</a>
                        @else
                        <a href="clientes/status/{{$cliente->id}}/1" class="btn btn-success product-btn"><i class="fa fa-toggle-on"></i> Ativar</a>
                        @endif

                        <a href="javascript:;" data-href="{{url('/')}}/admin/clientes/{{$cliente->id}}/deletar" data-toggle="modal" data-target="#confirmar-deletar"class="btn btn-danger product-btn"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        </div>
        <hr/>
    </div>
</div>
</div>
</div>
<!-- Ending of Dashboard Users area -->
</div>
</div>
</div>
</div>

<div class="modal fade" id="confirmar-deletar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div style="background-color: #f5f5f5;" class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><i class="fa fa-fw fa-exclamation-circle"></i> Confirmar Exclusão</h4>
                </div>
                <div style="background-color: #f5f5f5;" class="modal-body">
                    <p style="font-weight: bold;">Você está prestes a excluir este cliente. Todos os dados serão excluídos para este cliente.</p>
                    <h4 style="font-weight: bold;">Você deseja prosseguir ?</h4>
                </div>
                <div style="background-color: #f5f5f5;" class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal"><i class="fa fa-fw fa-close"></i>Cancelar</button>
                    <a class="btn btn-danger btn-ok"><i class="fa fa-fw fa-trash"></i> Excluir</a>
                </div>
            </div>
        </div>
    </div>

@stop

@section('footer')

<script>
$('#confirmar-deletar').on('show.bs.modal', function(e) {
$(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});
</script>

@stop