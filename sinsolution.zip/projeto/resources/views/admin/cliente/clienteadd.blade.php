@extends('admin.includes.masterpage-admin')

@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
{{-- Inicio --}}
<div class="section-padding add-product-1">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="add-product-box">
                <div class="add-product-header">
                    <h2 class="title">Adicionar cliente</h2>
                    <a href="{!! url('admin/clientes') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> voltar</a>
                </div>
                <hr/>
                <div id="response">                                        
                    @if(Session::has('message'))
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        {{ Session::get('message') }}
                    </div>
                @endif
                </div>
                <form method="POST" action="{!! action('ClientesController@store') !!}" class="form-horizontal" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="foto">Foto de perfil*</label>
                        <div class="col-sm-6">
                            <img src="{{ URL::asset('assets/images/produto/padrao.png')}}" style="max-width: 200px;" alt="Nenhuma foto adicionada" id="foto">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="foto">Selecionar foto *</label>
                        <div class="col-sm-6">
                            <input type="file" accept="image/*" name="foto" class="hidden" onchange="readURL(this)" id="uploadFile"/>
                            <div id="uploadTrigger" class="btn btn-info"><span class="fa fa-cloud-upload"></span> Click para adicionar a foto!</div><br><br>
                            <span style="color: green; font-weight: bold;">Proporção preferível 1x1</span>
                        </div>
                    </div>                    
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="nome">Nome Completo*</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="nome" id="nome" placeholder="Ex: Fulano de tal" required>
                        </div>
                    </div>

                    <div class="form-group">
                    <label class="control-label col-sm-3" for="service_text">E-mail* <span style="color: red; font-weight: bold;">(Será usado para login)</span></label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" name="email" placeholder="O e-mail será usado para fazer o login no sistema" id="email" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-3" for="data_de_nascimento">Data de Nascimento*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="data_de_nascimento" value="01-01-1950" id="data_de_nascimento" readonly required>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="control-label col-sm-3" for="usuario">Nome de Usuário*</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="usuario" id="usuario" placeholder="Ex: nickname">
                        </div>
                    </div>                                       
                    
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="password">Senha* <span style="color: red; font-weight: bold;">(Será usada para login)</span></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Informe a senha" id="password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="password_confirmation">Confirme a Senha*</label>
                        <div class="col-sm-6">
                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirma sua senha">
                    </div>
                    </div>
                                

                    <hr/>
                    <div class="add-product-footer">
                        <button style="height: 41px;" name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-fw fa-save"></i> Adicionar cliente</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
{{-- Fim --}}

</div>
</div>
</div>
</div>


@stop

@section('footer')
    <script type="text/javascript">


        $("#uploadTrigger").click(function(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                $("#uploadTrigger").html($("#uploadFile").val());
            });
        });
        function readURL(input) {

            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#foto').attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        bkLib.onDomLoaded(function() {
            new nicEditor({fullPanel : true}).panelInstance('descricao');
        });
    </script>
<script type="text/javascript">    
$('#data_de_nascimento').datepicker({
    changeMonth: true,
    changeYear: true,  
    showHour: false,
    showMinute: false,
    showSecond: false,
    dateFormat: 'dd-mm-yy',
    timeFormat: 'HH:mm:ss',    
    stepHour: 1,
    stepMinute: 1,
    stepSecond: 1,
});
</script>
@stop