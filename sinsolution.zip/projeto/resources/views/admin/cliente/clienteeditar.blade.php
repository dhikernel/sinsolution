@extends('admin.includes.masterpage-admin')

@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard Edit customer area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2 class="title">Editar Cliente</h2>
                                        <a href="{!! url('admin/clientes') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                                    </div>
                                    <hr/>
                                    <form method="POST" action="{!! action('ClientesController@update',['id' => $cliente->id]) !!}" class="form-horizontal form-label-left" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <input type="hidden" name="_method" value="PATCH">

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="foto">Foto de perfil*</label>
                                            <div class="col-sm-6">
                                                @if($cliente->foto == '')
                                                <img src="{{ URL::asset('assets/images/userprofile/padrao.png')}}" style="max-width: 200px;" alt="Nenhuma foto adicionada" id="foto">
                                                @else
                                                <img src="{{ URL::asset('assets/images/userprofile')}}/{{$cliente->foto}}" style="max-width: 200px;" alt="Nenhuma foto adicionada" id="foto">
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="foto">Selecionar foto *</label>
                                            <div class="col-sm-6">
                                                <input type="file" accept="image/*" name="foto" class="hidden" onchange="readURL(this)" id="uploadFile"/>
                                                <div id="uploadTrigger" class="btn btn-info"><span class="fa fa-cloud-upload"></span> Click para adicionar a foto!</div><br><br>
                                                <span style="color: green; font-weight: bold;">Proporção preferível 1x1</span>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="nome">Nome*</span></label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="nome" value="{{$cliente->nome}}" id="nome" placeholder="Nome" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="email">E-mail*</span></label>
                                            <div class="col-sm-6">
                                                <input type="email" name="email" id="email" class="form-control" placeholder="Informe seu e-mail" value="{{$cliente->email}}" required>                
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <label class="control-label col-sm-3" for="data_de_nascimento">Data de Nascimento*</span></label>
                                            <div class="col-sm-6">
                                            <input type="text" class="form-control" name="data_de_nascimento" id="data_de_nascimento" readonly required value="{{$cliente->data_de_nascimento}}">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="usuario">Nome do cliente*</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="usuario" id="usuario" placeholder="Ex: fulado de tal" value="{{$cliente->usuario}}">
                                            </div>
                                        </div>
                                       
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button style="height: 41px;" name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar cliente</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- Fim --}}

                </div>
            </div>
        </div>
    </div>

@stop

@section('footer')
    <script type="text/javascript">


        $("#uploadTrigger").click(function(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                $("#uploadTrigger").html($("#uploadFile").val());
            });
        });
        function readURL(input) {

            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#foto').attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        bkLib.onDomLoaded(function() {
            new nicEditor({fullPanel : true}).panelInstance('descricao');
        });
    </script>
<script type="text/javascript">    
$('#data_de_nascimento').datepicker({
    changeMonth: true,
    changeYear: true,  
    showHour: false,
    showMinute: false,
    showSecond: false,
    dateFormat: 'dd-mm-yy',
    timeFormat: 'HH:mm:ss',    
    stepHour: 1,
    stepMinute: 1,
    stepSecond: 1,
});
</script>
@stop