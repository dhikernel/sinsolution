@extends('admin.includes.master-admin')

@section('content')

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">

                {{-- Cabeçalho da página --}}
                <div class="go-title">
                    <h3>Configurações Gerais</h3>
                    <div class="go-line"></div>
                </div>
                {{-- Conteúdo da Página --}}
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="res">
                            @if(Session::has('message'))
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    {{ Session::get('message') }}
                                </div>
                            @endif
                        </div>
                        {{-- /.inicio --}}
                        <div class="col-md-12">
                            <ul class="nav nav-tabs tabs-left">
                                <li class="active"><a href="#logo" data-toggle="tab" aria-expanded="true">Logo</a>
                                <li class=""><a href="#favicon" data-toggle="tab" aria-expanded="true">Favicon</a>
                                <li class=""><a href="#website" data-toggle="tab" aria-expanded="false">Conteúdo do site</a>
                                <li class=""><a href="#payment" data-toggle="tab" aria-expanded="false">Informação de pagamento</a>

                                <li class=""><a href="#background" data-toggle="tab" aria-expanded="false">Imagem de fundo</a>
                                </li>
                                <li class=""><a href="#about" data-toggle="tab" aria-expanded="false">Sobre Nós</a>
                                </li>
                                <li class=""><a href="#address" data-toggle="tab" aria-expanded="false">Endereço</a>
                                </li>
                                <li class=""><a href="#footer" data-toggle="tab" aria-expanded="false">Rodapé</a>
                                </li>
                            </ul>
                        </div>

                        <div class="col-xs-9">
                            {{-- Guias --}}
                            <div class="tab-content">
                                <div class="tab-pane active" id="logo">
                                    <p class="lead">Logo do Site</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/logo" class="form-horizontal form-label-left" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Logo Atual
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <img class="col-md-6" src="../assets/images/logo/{{$setting[0]->logo}}">
                                            </div>

                                        </div>
                                        <br>                                        
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Configurar novo logotipo <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input type="file" name="logo" required/>
                                            </div>

                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                
                                                <button type="submit" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="favicon">
                                    <p class="lead">Favicon do Site</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/favicon" class="form-horizontal form-label-left" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Favicon atual
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <img class="col-md-3" src="../assets/images/{{$setting[0]->favicon}}">
                                            </div>

                                        </div>
                                        <br>                                        
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Configurar Novo Favicon <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input type="file" name="favicon" required/>
                                            </div>

                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">          
                                                <button type="submit" class="btn btn-success add-product_btn">Atualizar configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="website">
                                    <p class="lead">Conteúdo do site</p>

                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/title" class="form-horizontal form-label-left" id="website_form">
                                                {{csrf_field()}}
                                            <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-3 col-xs-12" for="title"> Título do site <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="title" placeholder="Título do Site" required="required" type="text" value="{{$setting[0]->title}}">
                                            </div>
                                        </div>
                                        
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-3 col-xs-12" for="facebook"> Mostrar/Esconder Seção da Galeria <span class="required">*</span>
                                            </label>
                                            <div class="col-md-3 col-sm-3 col-xs-9">
                                                @if($setting[0]->gallery_status == 1)
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="gallery_status" value="1" data-off="Hidden" checked>
                                                @else
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="gallery_status" value="1" data-off="Hidden">
                                                @endif
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-3 col-xs-12" for="facebook"> Mostrar/Esconder Seção Depoimentos <span class="required">*</span>
                                            </label>
                                            <div class="col-md-3 col-sm-3 col-xs-9">
                                                @if($setting[0]->testi_status == 1)
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="testi_status" value="1" data-off="Hidden" checked>
                                                @else
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="testi_status" value="1" data-off="Hidden">
                                                @endif
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-3 col-xs-12" for="facebook"> Mostrar/Esconder Seção Serviços <span class="required">*</span>
                                            </label>
                                            <div class="col-md-3 col-sm-3 col-xs-9">
                                                @if($setting[0]->testi_status == 1)
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="service_status" value="1" data-off="Hidden" checked>
                                                @else
                                                    <input type="checkbox" data-toggle="toggle" data-on="Shown" name="service_status" value="1" data-off="Hidden">
                                                @endif
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">         
                                                <button type="submit" id="website_update" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="payment">
                                    <p class="lead">Informações de Pagamento</p>

                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/payment" class="form-horizontal form-label-left" id="website_form">
                                                {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Conta Empresarial Paypal <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="paypal" placeholder="Paypal Business" required="required" type="text" value="{{$setting[0]->paypal_business}}">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Chave do Stripe <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="stripe_key" placeholder="Stripe Key" required="required" type="text" value="{{$setting[0]->stripe_key}}">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Chave Secreta do Stripe <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="stripe_secret" placeholder="Stripe Secret Key" required="required" type="text" value="{{$setting[0]->stripe_secret}}">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Taxa de Listagem Básica(R$) <span class="required">*</span>

                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="basic_charge" placeholder="Numérico" required="required" type="text" value="{{$setting[0]->basic_charge}}">
                                            </div>
                                        </div>

                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Lista de Destaque(R$) <span class="required">*</span>

                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="featured_charge" placeholder="Númerico" required="required" type="text" value="{{$setting[0]->featured_charge}}">
                                            </div>
                                        </div>

                                        <div class="item form-group">
                                            <label class="control-label col-md-4 col-sm-4 col-xs-12" for="title"> Retirar a Taxa(%) <span class="required">*</span>

                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input class="form-control col-md-7 col-xs-12" name="withdraw_charge" placeholder="Númerico" required="required" type="text" value="{{$setting[0]->withdraw_charge}}">
                                            </div>
                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <!--  <button type="submit" class="btn btn-primary">Cancel</button> -->
                                                <button type="submit" id="website_update" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="background">
                                    <p class="lead">Imagem de Fundo</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/background" class="form-horizontal form-label-left" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Imagem de Fundo Atual
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <img class="col-md-10" src="../assets/images/{{$setting[0]->background}}">
                                            </div>

                                        </div><br>
                                        <!-- <input type="hidden" name="id" value="1"> -->
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Configurar novo plano de fundo <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input type="file" name="background" required="required" />
                                            </div>
                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <!--  <button type="submit" class="btn btn-primary">Cancel</button> -->
                                                <button type="submit" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="about">
                                    <p class="lead">Sobre Nós</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/about" class="form-horizontal form-label-left" id="about_form">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="about"> Texto Sobre Nós <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <textarea rows="10" cols="60" id="aboutpnael" class="form-control" name="about">{{$setting[0]->about}}</textarea>
                                            </div>
                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <!--  <button type="submit" class="btn btn-primary">Cancel</button> -->
                                                <button type="submit" id="about_update" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="address">
                                    <p class="lead">Endereço</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/address" class="form-horizontal form-label-left" id="about_form">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address"> Endereço <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <textarea rows="3" cols="60" class="form-control col-md-7 col-xs-12" name="address" required="required">{{$setting[0]->address}}</textarea>
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Telefone <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="phone" placeholder="Número de Telefone" required="required" type="text" value="{{$setting[0]->phone}}">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="fax"> Fax <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="fax" placeholder="Fax" required="required" type="text" value="{{$setting[0]->fax}}">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email"> E-mail <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="email" placeholder="Endereço de E-mail" required="required" type="text" value="{{$setting[0]->email}}">
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <!--  <button type="submit" class="btn btn-primary">Cancel</button> -->
                                                <button id="office_update" type="submit" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane" id="footer">
                                    <p class="lead">Rodapé do Site</p>
                                    <div class="ln_solid"></div>
                                    <form method="POST" action="settings/footer" class="form-horizontal form-label-left" id="footer_form">
                                        {{csrf_field()}}
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="footer"> Texto do Rodapé <span class="required">*</span>
                                            </label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <textarea rows="2" cols="60" id="footerpnael" class="form-control" name="footer" required="required">{{$setting[0]->footer}}</textarea>
                                            </div>
                                        </div>

                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <!--  <button type="submit" class="btn btn-primary">Cancel</button> -->
                                                <button id="footer_update" type="submit" class="btn btn-success add-product_btn">Atualizar Configurações</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.end -->
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->



@stop

@section('footer')
    <script type="text/javascript">
        bkLib.onDomLoaded(function() {
            new nicEditor().panelInstance('aboutpnael');
            new nicEditor().panelInstance('footerpnael');
        });
    </script>
@stop